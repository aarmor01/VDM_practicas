package com.example.engine_android.Enums;

public enum FontType {
    DEFAULT,
    BOLD,
    ITALIC
}
