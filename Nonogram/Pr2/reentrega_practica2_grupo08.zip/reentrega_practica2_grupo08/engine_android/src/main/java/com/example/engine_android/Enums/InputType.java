package com.example.engine_android.Enums;

public enum InputType {
    TOUCH_DOWN,
    TOUCH_UP,
    TOUCH_MOVE,
    TOUCH_LONG
}