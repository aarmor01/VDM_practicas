package com.example.nonogram;

public class Resources {
    // images
    public static String IMAGE_BACK_BUTTON = null;
    public static String IMAGE_CHECK_BUTTON = null;

    // fonts
    public static String FONT_EXO_REGULAR_BIG = null;
    public static String FONT_EXO_REGULAR_MEDIUM = null;
    public static String FONT_KOMIKAX = null;
    public static String FONT_SIMPLY_SQUARE_BIG = null;
    public static String FONT_SIMPLY_SQUARE_MEDIUM = null;

    // sounds
    public static String SOUND_BUTTON = null;
    public static String SOUND_CLICK = null;
}